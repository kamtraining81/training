﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.DataModel;


namespace DynamoCrud
{
    class Program
    {
        static void createTableFunc()
        {
            var client = new AmazonDynamoDBClient();
            List<string> tableNames = client.ListTables().TableNames;

            if (!tableNames.Contains("Employee"))
            {
                var request = new CreateTableRequest
                {
                    TableName = "Employee",
                    AttributeDefinitions = new List<AttributeDefinition>
                    {
                        new AttributeDefinition
                        {
                            AttributeName="State",
                            AttributeType="S"
                        },
                        new AttributeDefinition
                        {
                            AttributeName="EmpId",
                            AttributeType="S"
                        }
                    },
                    KeySchema = new List<KeySchemaElement>
                    {
                        new KeySchemaElement
                        {
                            AttributeName="State",
                            KeyType="HASH"
                        },
                        new KeySchemaElement
                        {
                            AttributeName="EmpId",
                            KeyType="RANGE"
                        }
                    },
                    ProvisionedThroughput = new ProvisionedThroughput
                    {
                        ReadCapacityUnits = 2,
                        WriteCapacityUnits = 2


                    }
                };
                var response = client.CreateTable(request);
                Console.WriteLine("Table created with the Id :" + response.ResponseMetadata.RequestId);
            }

        }
        static void describeTableFunc()
        {
            var client = new AmazonDynamoDBClient();
            var descTableReq = new DescribeTableRequest
            {
                TableName = "Employee"
            };
            var response = client.DescribeTable(descTableReq);
            Console.WriteLine("Description of Table");
            Console.WriteLine("Table Name " + response.Table.TableName);
            Console.WriteLine("Table Status " + response.Table.TableStatus);
            List<KeySchemaElement> pk = response.Table.KeySchema;
            foreach (KeySchemaElement item in pk)
            {
                Console.WriteLine("Table Keys " + item.AttributeName + " Type :" + item.KeyType);
            }

        }
        static void insertItem()
        {
            var client = new AmazonDynamoDBClient();
            var putRequest = new PutItemRequest
            {
                TableName = "Employee",
                Item = new Dictionary<string, AttributeValue>
                {
                    {"State",new AttributeValue{ S="Karnataka"} },
                    {"EmpId",new AttributeValue{S="E104"} },
                    {"Salary",new AttributeValue{N="987"} },
                    {"EmpName",new AttributeValue{S="Ram"} },

                },
                ReturnConsumedCapacity = ReturnConsumedCapacity.TOTAL,
                ReturnValues = ReturnValue.ALL_OLD
            };
            var response = client.PutItem(putRequest);
            Console.WriteLine("Response of putItem: ");
            Console.WriteLine("Consumed Capacity " + response.ConsumedCapacity.WriteCapacityUnits);

        }

        static void getItemUsingDocumentModel()
        {
            var client = new AmazonDynamoDBClient();
            var table = Table.LoadTable(client, "Employee");
            Document item = table.GetItem("Tamil Nadu", "E109");
            if (item != null)
            {
                // getItem -- return 0 or 1 item;
                //Console.WriteLine("State : "+ item["State"]);
                //Console.WriteLine("EmpId : "+ item["EmpId"]);
                foreach (var field in item)
                {
                    Console.WriteLine(field.Key + " : " + field.Value);
                }
            }
            else
            {
                Console.WriteLine("No items matched the primary key");
            }
        }

        static void insertIntoBooksUsingObjectPersistence()
        {
            var client = new AmazonDynamoDBClient();
            var reviews = new List<string>();
            reviews.Add("Very Good");
            reviews.Add("Excellent");
            var bookToBeInserted = new Books
            {
                BookId = 301,
                BookName = "Book3",
                Author = "Paul Coelho",
                ISBN = "333-333328",
                price = 1023,
                reviews = reviews
            };
            var context = new DynamoDBContext(client);
            context.Save(bookToBeInserted);
            Console.WriteLine("Insertion successful");
        }
        static void getItemUsingObjectPersistence()
        {
            var client = new AmazonDynamoDBClient();
            var context = new DynamoDBContext(client);
            Books bookRead = context.Load<Books>("Paul Coelho", 111);
            if (bookRead != null)
            {
                Console.WriteLine("/n Book Id : " + bookRead.BookId);
                Console.WriteLine("Book Name : " + bookRead.BookName);
                Console.WriteLine("Book Author : " + bookRead.Author);
                Console.WriteLine("Reviews:");
                foreach (string review in bookRead.reviews)
                {
                    Console.Write(review + " ");
                }
            }
            else
            {
                Console.WriteLine("No items matched the primary key");
            }
        }
        static void queryItemUsingObjectPersistence()
        {
            var client = new AmazonDynamoDBClient();
            var context = new DynamoDBContext(client);
            // Only with the partitionKey
            //IEnumerable<Books> booksResponse=context.Query<Books>("Paul Coelho");

            // With the partition key and sort key (BookId between 100 and 200)
            //IEnumerable<Books> booksResponse=context.Query<Books>("Paul Coelho", QueryOperator.Between,100,200);

            // With the partition key and sort key (BookId between 100 and 200) and filter condition

            ScanCondition qF = new ScanCondition("price", ScanOperator.GreaterThan, 500);
            List<ScanCondition> listQF = new List<ScanCondition>();
            listQF.Add(qF);
            IEnumerable<Books> booksResponse = context.Query<Books>("Paul Coelho",
                new DynamoDBOperationConfig
                {
                    QueryFilter = listQF
                });

            foreach (Books book in booksResponse)
            {
                Console.WriteLine("\n Book Id : " + book.BookId);
                Console.WriteLine("Book Name : " + book.BookName);
                Console.WriteLine("Book Author : " + book.Author);
                Console.WriteLine("Reviews:");
                foreach (string review in book.reviews)
                {
                    Console.Write(review + " ");
                }
            }
        }
        static void scanTableUsingObjectPersistence()
        {
            var client = new AmazonDynamoDBClient();
            var context = new DynamoDBContext(client);
            //IEnumerable<Books> booksResponse = context.Scan<Books>();
            ScanCondition qF = new ScanCondition("price", ScanOperator.GreaterThan, 500);
            ScanCondition qF2 = new ScanCondition("BookName", ScanOperator.BeginsWith, "B");

            List<ScanCondition> listQF = new List<ScanCondition>();
            listQF.Add(qF);
            //Scan with filters:
            IEnumerable<Books> booksResponse = context.Scan<Books>(qF, qF2);
            foreach (Books book in booksResponse)
            {
                Console.WriteLine("***********************");
                Console.WriteLine("\n Book Id : " + book.BookId);
                Console.WriteLine("Book Name : " + book.BookName);
                Console.WriteLine("Book Author : " + book.Author);
                Console.WriteLine("Price : " + book.price);
                Console.WriteLine("Reviews:");
                foreach (string review in book.reviews)
                {
                    Console.Write(review + " ");
                }
                Console.WriteLine("\n***********************");
            }
        }
        static void updateItemsConditionally()
        {
            var client = new AmazonDynamoDBClient();

            var updateReq = new UpdateItemRequest
            {
                TableName="Employee",
                Key = new Dictionary<string, AttributeValue>
                {
                  {
                    "State",new AttributeValue{S="Tamil Nadu"}
                    },
                    {
                        "EmpId",new AttributeValue {S="E101"}
                    }
                },
                UpdateExpression="SET Salary =:newsal REMOVE #sal",
                //ConditionExpression="Salary=:oldsal",
                ConditionExpression="begins_with(EmpName,:startChar)",
                ExpressionAttributeNames=new Dictionary<string, string>
                {
                    {"#sal","salary" }
                },
                ExpressionAttributeValues=new Dictionary<string, AttributeValue>
                {
                    {":newsal",new AttributeValue{N="10000"} },
                    //{":oldsal",new AttributeValue{N="1000"} },
                    {":startChar",new AttributeValue{S="S"} },
                },
                ReturnValues="ALL_NEW"
            };
            try
            {
                var response = client.UpdateItem(updateReq);
                var attributes = response.Attributes;
                Console.WriteLine("Item after updation");
                foreach (var item in attributes)
                {
                    Console.WriteLine(item.Key + " : " + (item.Value.S == null ? item.Value.N : item.Value.S));
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("Item could not be updated because it failed the condition");
                Console.WriteLine(e.InnerException.Message);
            }


        }
        static void updateItems()
        {
            var client = new AmazonDynamoDBClient();

            var updateReq = new UpdateItemRequest
            {
                TableName = "Employee",
                Key = new Dictionary<string, AttributeValue>
                {
                  {
                    "State",new AttributeValue{S="Tamil Nadu"}
                    },
                    {
                        "EmpId",new AttributeValue {S="E101"}
                    }
                },
                UpdateExpression = "SET Salary =:newsal REMOVE #sal",
                ExpressionAttributeNames = new Dictionary<string, string>
                {
                    {"#sal","salary" }
                },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    {":newsal",new AttributeValue{N="1000"} }
                },
                ReturnValues = "ALL_NEW"
            };
            var response = client.UpdateItem(updateReq);
            var attributes = response.Attributes;
            Console.WriteLine("Item after updation");
            foreach (var item in attributes)
            {
                Console.WriteLine(item.Key + " : " + (item.Value.S == null ? item.Value.N : item.Value.S));
            }



        }
        static void deleteItem()
        {
            var client = new AmazonDynamoDBClient();

            var deleteReq = new DeleteItemRequest
            {
                TableName = "Employee",
                Key = new Dictionary<string, AttributeValue>
                {
                  {
                    "State",new AttributeValue{S="Tamil Nadu"}
                    },
                    {
                        "EmpId",new AttributeValue {S="E101"}
                    }
                },
                
                ReturnValues = "ALL_OLD"
            };
            var response = client.DeleteItem(deleteReq);
            var attributes = response.Attributes;
            Console.WriteLine("Item before deletion");
            foreach (var item in attributes)
            {
                Console.WriteLine(item.Key + " : " + (item.Value.S == null ? item.Value.N : item.Value.S));
            }
            Console.WriteLine("Item deleted successfully");


        }
        static void deleteItemConditionally()
        {
            var client = new AmazonDynamoDBClient();

            var deleteReq = new DeleteItemRequest
            {
                TableName = "Employee",
                Key = new Dictionary<string, AttributeValue>
                {
                  {
                    "State",new AttributeValue{S="Karnataka"}
                    },
                    {
                        "EmpId",new AttributeValue {S="E104"}
                    }
                },
                ConditionExpression="Salary between :low and :high",
                
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    {":low",new AttributeValue{N="500"} },
                    {":high",new AttributeValue{N="1000"} },
                },
                ReturnValues = "ALL_OLD"
            };
            var response = client.DeleteItem(deleteReq);
            var attributes = response.Attributes;
            Console.WriteLine("Item before deletion");
            foreach (var item in attributes)
            {
                Console.WriteLine(item.Key + " : " + (item.Value.S == null ? item.Value.N : item.Value.S));
            }
        }
        static void paginationExample()
        {
            var client = new AmazonDynamoDBClient();
            Dictionary<string, AttributeValue> lastEvaluatedKey = null;
            do
            {
                var request = new QueryRequest
                {
                    TableName = "Books",
                    KeyConditionExpression = "Author=:author",
                    ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                    {
                        {":author",new AttributeValue {S="Paul Coelho"} }
                    },
                    Limit=1,
                    ExclusiveStartKey=lastEvaluatedKey
                };
                var response=client.Query(request);
                foreach(Dictionary<string,AttributeValue> row in response.Items)
                {
                    Console.WriteLine("\n ********************");

                   foreach(var item in row)
                    {
                        Console.Write("\n "+ item.Key + " : ");
                        Console.Write((item.Value.S == null ? item.Value.N : item.Value.S));
                        Console.Write((item.Value.SS != null ? string.Join(",", item.Value.SS.ToArray()) : ""));
                    }
                    
                }
                lastEvaluatedKey = response.LastEvaluatedKey;
            }
            while (lastEvaluatedKey != null && lastEvaluatedKey.Count != 0);
        }

        static void Main(string[] args)
        {
            try
            {
                //createTableFunc();
                describeTableFunc();
                //insertItem();
                //getItemUsingDocumentModel();
                //insertIntoBooksUsingObjectPersistence();
                //getItemUsingObjectPersistence();
                //queryItemUsingObjectPersistence();
                //scanTableUsingObjectPersistence();
                //updateItems();
                //updateItemsConditionally();
                //deleteItem();
                //deleteItemConditionally();
                paginationExample();
            }
            catch (AmazonDynamoDBException err)
            {
                Console.WriteLine("Error : " + err.Message);
            }
            catch (Exception err)
            {
                Console.WriteLine("Error : " + err.Message);
            }
            Console.ReadLine();

        }
    }
}
/*.Net Sdk
 * 3 models are available
 * Low level Api
 * Document Model
 * Object Persistence Model
 * 
 */
