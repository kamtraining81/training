﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.DataModel;

namespace DynamoCrud
{
    [DynamoDBTable("Books")]
    class Books
    {
        [DynamoDBRangeKey]
        public int BookId { get; set; }
        public string BookName { get; set; }
        [DynamoDBHashKey]
        public string Author { get; set; }
        public string ISBN { get; set; }
        public int price { get; set; }
        public List<string> reviews { get; set; }
    }
}
