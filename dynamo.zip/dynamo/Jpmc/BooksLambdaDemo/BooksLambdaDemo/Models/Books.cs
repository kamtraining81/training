﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooksLambdaDemo.Models
{
    [DynamoDBTable("books")]
    public class Books
    {
        [DynamoDBHashKey("bookId")]
        public string BookId {get; set;}

        [DynamoDBProperty("title")]
        public string Title { get; set;}

        [DynamoDBProperty("author")] 
        public string Author { get; set;}

        [DynamoDBProperty("isbn")] 
        public string ISBN { get; set;}
    }
}
