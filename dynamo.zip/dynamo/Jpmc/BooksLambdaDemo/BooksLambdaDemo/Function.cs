using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using BooksLambdaDemo.Models;
using Newtonsoft.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace BooksLambdaDemo;

public class Function
{
    
    /// <summary>
    /// A simple function that takes a string and does a ToUpper
    /// </summary>
    /// <param name="input"></param>
    /// <param name="context"></param>
    /// <returns></returns>
    //public string FunctionHandler(string input, ILambdaContext context)
    //{
    //    return input.ToUpper();
    //}

    public async Task<List<Books>> GetAllBooks(APIGatewayHttpApiV2ProxyRequest request, ILambdaContext context)
    {
        AmazonDynamoDBClient client=new AmazonDynamoDBClient();
        DynamoDBContext dBContext = new DynamoDBContext(client);
        var data=await dBContext.ScanAsync<Books>(default).GetRemainingAsync();
        return data;
    }

    public async Task<Books> GetBookById(APIGatewayHttpApiV2ProxyRequest request, ILambdaContext context)
    {
        AmazonDynamoDBClient client = new AmazonDynamoDBClient();
        DynamoDBContext dBContext = new DynamoDBContext(client);
        string bookId=request.PathParameters["bookId"];
        var book = await dBContext.LoadAsync<Books>(bookId);
        if (book == null )
        {
            throw new Exception("Book with the given Id not found");
        }

        return book;
    }

    public async Task<APIGatewayHttpApiV2ProxyResponse> InsertBook(APIGatewayHttpApiV2ProxyRequest request, ILambdaContext context)
    {
        AmazonDynamoDBClient client = new AmazonDynamoDBClient();
        DynamoDBContext dBContext = new DynamoDBContext(client);
        var bookDetails = JsonConvert.DeserializeObject<Books>(request.Body);
        await dBContext.SaveAsync<Books>(bookDetails);
        var msg = $"Book with Book Id : {bookDetails.BookId} inserted";
        return new APIGatewayHttpApiV2ProxyResponse
        {
            Body = msg,
            StatusCode = 200,
        };

            }




}
