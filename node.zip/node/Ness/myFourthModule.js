var obj=require("./myThirdModule");
var res=obj.calcMul(10,20);
console.log("Mul of 2 numbers is",res);
