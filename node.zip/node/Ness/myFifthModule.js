var calcSum=require("./myFirstModule"); // execute the myFirstModule -- console.log will be printed
var calcDiv=require("./mySecondModule");// here internally also firstModule will not be excuted, it would be using the cached version 

var res=calcSum(10,20);
var res1=calcDiv(10,20);

console.log("Res",res);
console.log("Res1",res1);