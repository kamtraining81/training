var fs=require("fs");//fs -- file systems; core module; shipped along with nodejs; no explicit installation required
var path=require("path");// core module

console.log("hi");
// read a file
//var filePath=path.join("C:","Users","anjum","OneDrive","Desktop","Ness","NodeJS TOC _updated on 6th May.pdf")
var result=fs.readFile("file1.txt",(err,data)=>{
    if(err)
        {
            console.log("Error ",err)
        }
    else
    {
        console.log(data.toString());
    }
});
console.log("Result",result);
console.log("bye");

