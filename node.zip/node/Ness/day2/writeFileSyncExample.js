var fs = require("fs");

// sync function -- no callback;
// enclose with a try catch block -- catch the error if the opeartion is unsuccesful
try {
    console.log("Hello");

    fs.writeFileSync("file4.txt", "Welcome to nodejs");
    console.log("Write operation successful");
    console.log("bye");
}
catch(ex)
{
    console.log("Exception",ex);
}
