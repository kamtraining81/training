var fs=require("fs");

// read the contents from 2 file and write it to third file

fs.readFile("file1.txt",(err,data1)=>{
    if(err)
        {
            console.log("error",err);
        }
    else
    {
        fs.readFile("file2.txt",(err,data2)=>{
            if(err)
                {
                    console.log("error",err);
                }
            else
            {
                fs.writeFile("file6.txt",(data1),(err)=>{
                    if(err)
                        {
                            console.log(err);
                        }
                    else
                    {
                        fs.writeFile("file6.txt",data2,{flag:"a"},(err)=>{
                            if(err)
                                {
                                    console.log(err);
                                }
                            else
                            {
                                console.log("Operation completed successfully")
                            }
                        })
                    }
                });
                

            }
        })
    }
})

/*
// file1 -- 100mb(read -- 10sec); file2--1000mb(read - 100 sec) 
var firstDataContent;
fs.readFile("file1.txt",(err,data1)=>{
    if(err)
        {
            console.log(err);
        }
    else
    {
        firstDataContent=data1;
    }
})

fs.readFile("file2.txt",(err,data2)=>{
    if(err)
        {
            console.log(err);
        }
})

//console.log(data1);// not possible
console.log(firstDataContent);// ud

*/