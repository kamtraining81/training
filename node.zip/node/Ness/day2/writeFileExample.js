var fs=require("fs");//fs -- file systems; core module; shipped along with nodejs; no explicit installation required
var path=require("path");// core module


fs.writeFile("file2.txt","Welcome to express",{flag:"a"},(err)=>{
    if(err)
        {
            console.log("Error",err)
        }
    else
    {
        console.log("Write operation successful");
    }
})
// if file does not exists, it created the file
// if file exists, it will overwrite
// if file exists, lets append the data