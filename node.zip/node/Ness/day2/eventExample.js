var events=require("events");

var myEvent=new events.EventEmitter();
var totalScore=0;
// Declare the events
// Attach the event handler with the events
myEvent.on("join",()=>{
    console.log("Welcome to the session");
})

myEvent.on("end",()=>{
    console.log("Thank u for attending the session");
})

myEvent.on("feedback",(score,comments)=>{
    console.log("Score received",score);
    totalScore+=score;
})

myEvent.on("feedback",(score,comments)=>{
    console.log("totalScore",totalScore);
    console.log("comments",comments)
    if(totalScore <2)
        {
            console.log("Work harder")
        }
    else
    {
        console.log("Going good");
    }
})

// trigger the event
myEvent.emit("join");
myEvent.emit("feedback",5,"Interesting");
myEvent.emit("end");
myEvent.emit("feedback",7);

// not function overloading
// function overloading -- only one function will be executed 
// both the event handlers are executed for the same event 

// Declare the events and event handler in one module ; In another module we can trigger the events

myEvent.once("Complete",()=>{
    console.log("Closing the file permanently");
})

myEvent.emit("Complete");
myEvent.emit("Complete");
console.log("Number of listeners",myEvent.listenerCount("feedback"));
console.log("Listerners for the feedback event",myEvent.listeners("feedback"));

var ctr=0;
function inCtr()
{
    ctr++;
    console.log("Ctr",ctr);
    if(ctr >2)
        {
            myEvent.removeListener("incrementCtr",inCtr);
        }
}
myEvent.on("incrementCtr",inCtr);

myEvent.emit("incrementCtr");
myEvent.emit("incrementCtr");
myEvent.emit("incrementCtr");
myEvent.emit("incrementCtr");
myEvent.emit("incrementCtr");
// on method -->