var express=require("express");
var http=require("http");
var socketio=require("socket.io");
var querystring=require("querystring");
var path=require("path");

var {addUser}=require("./utils/userManage");


const port=3000;
var app=express();
var server=http.createServer(app);
var io=socketio(server);

app.use(express.static(path.join(__dirname,"public")));
app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.get("/",(req,res)=>{
    var filePath=path.join(__dirname,"public","index.html");
    res.sendFile(filePath);
});
app.post("/home",(req,res)=>{
    console.log("data in request body",req.body);
    var {userName,roomName}=req.body;
    var myQueryString=querystring.stringify({userName:userName,roomName:roomName});
    res.redirect("/chat?"+myQueryString);

})
app.get("/chat",(req,res)=>{
    var filePath=path.join(__dirname,"public","chat.html");
    res.sendFile(filePath);
});

// when a new client joins in ; whenever index.html loads
io.on("connection",(socket)=>{
    console.log("New client joined");// socket is a stream
    socket.on("joinChat",(dataObj)=>{
        // whenever chat.html loads
        // new user has joined in
        console.log("User joined",dataObj);
        addUser(dataObj.userName,dataObj.roomName,socket);
        socket.broadcast.emit("newUserJoin",dataObj);

    

    })
    socket.on("newMessage",(message)=>{
        io.emit("addMessage",message);
    })
    socket.on("disconnect",(socket)=>{
        var message={userName:"",roomName:"",message:"Has left"}
        io.emit("addMessage",message);
    })

})

io.on("disconnect",()=>{
    console.log("Server is down");
})


server.listen(port,(err)=>{
    if(err)
        {
            console.log("Error in starting the server",err)
        }
    else
    {
        console.log(`Server is running at http://localhost:${port}`);
    }

})