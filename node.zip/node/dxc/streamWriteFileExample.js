/*
Write huge contents into a file
Hige contents is going to broken up ;
Write each chunk seperately
*/
const fs=require("fs");
var myWriteStream=fs.createWriteStream("text6.txt");
myWriteStream.on("error",(err)=>{
    if(err)
    {
        console.log("Error during the write operation of the chunk"+ err);
    }
})
myWriteStream.write("This is the first line");// trigger an event "data"
myWriteStream.write("This is the second line");
myWriteStream.write("This is the third line");
myWriteStream.write("This is the fourth line");
myWriteStream.end(()=>{
    console.log("Finished writing to the file");
});// Finished writing the entire data // trigger an event "end"
myWriteStream.write("Trying to write after the end");// throw an error 
