const events=require("events");
var myEvent=new events.EventEmitter();

// Event handlers
myEvent.on("register",()=>{
    console.log("U have been registered for the course");
})

myEvent.on("studyMaterialAdded",()=>{
    console.log("Study Material Added");
})

myEvent.on("assessmentScore",(marks)=>{
    let sum=0;
    for(let i=0;i<marks.length;i++)
    {
        sum+=marks[i];
    }
    console.log("Total marks"+ sum)
})

// Trigger an event
myEvent.emit("register");

myEvent.emit("studyMaterialAdded");

myEvent.emit("assessmentScore",[20,30,40]);


/*
Emit the same event multiple time
Attach a event with multiple event listeners
On -- Attaching an event with a event listener
Once --Attaching an event with a event listener; Event can be triggered only once
*/
var fruits=[];
myEvent.once("createArray",(...p1)=>{
    fruits=[...p1];
})

myEvent.on("addFruit",(fruit)=>{
    fruits.push(fruit);
})

myEvent.on("removeFruit",(fruit)=>{
    var pos=fruits.findIndex(p1=> p1 == fruit);
    if(pos >=0)
    {
        fruits.splice(pos,1);
    }
})



myEvent.emit("createArray","apple","banana");
console.log("After creation ",fruits);//["apple","banana"]
myEvent.emit("createArray","guavas","strawberry");
console.log("After creation ",fruits);//["apple","banana"]

myEvent.emit("addFruit","guavas");
myEvent.emit("addFruit","strawberry");
console.log("After addition ",fruits)
