console.log("Welcome DXC");
console.log("Module1");

var i=10;
function squareFunc(p1)
{
    return p1*p1;
}
// local to that module 
// whatever has to be availbale in other modules, we need to export them
module.exports=squareFunc;