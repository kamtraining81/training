// Callbacks Promises async await; 
//closures
// javascript is asynchronous language

function func1()
{
    console.log("Hello");
    setInterval(()=>{
        console.log("Inside the interval");
    },1000)
    console.log("bye");
}
func1();//Hello bye .... Inside the interval ... Inside the interval ....

// Asynchronous tasks -- time oriented, sending the request and getting the response
function func2(p1)
{
    // send a request; wait for response ; once the response is received , process the response
    setTimeout(()=>{
        if(p1%2==0)
            return (`${p1} is an even number`)
        else
            return (`${p1} is an odd number`);
    },1000)
}
var result=func2(10);// 
console.log("Result"+result);// ud

// Callbacks, promise , async await
//1. Promise
/*
Promise -- working with an asynchronous task
promise 3 stages
    -- start stage -- the async op is going to start
    -- pending stage -- async op is running
    -- resolved stage -- async op has completed successfully
    -- rejected stage -- async op has failed
Promise can be either be rejected or resolved

If the promise is resolved , the then part will be executed
If the promise is rejected , the catch part will be executed

*/
function func3(p1)
{
    if(p1%2 ==0)
    {
        return Promise.resolve(`${p1} is an even number`);
    }
    else
    {
        return Promise.reject(`${p1} is an odd number`);
    }
}

var myPromise=func3(9);// return a promise which has been resolved
myPromise
.then(data =>{
    console.log(data);
})
.catch(err=>{
    console.log("Error "+ err);
})

function func3(p1)
{
    var myPromise =new Promise((resolve,reject)=>{
        setTimeout(()=>{
            if(p1%2 ==0)
            {
                resolve(`${p1} is an even number`);
            }
            else
            {
                reject(`${p1} is an odd number`);
            }
        },10000)
    })
    return myPromise;
    
}
func3(100)
.then((res)=>{console.log("Result"+res)})
.catch((err)=>{
    console.log(err);
})

// callback 
/*
Asynchronous task
callback function
min 1 param
1st param -- error value
2nd param -- data

*/
function func4(p1,callbackFunc)
{
    // send a request; wait for response ; once the response is received , process the response
    setTimeout(()=>{
        if(p1%2==0)
            callbackFunc(null,`${p1} is an even number`)
        else
            callbackFunc(`${p1} is an odd number`,null);
    },1000)
}

func4(50,(err,data)=>{
    if(err)
    {
        console.log("Error "+err);
    }
    else
    {
        console.log("Success "+ data);
    }
})

// async and await
/*
Used with a async function
To avoid callback hell -- work with async and await 
*/
//Nodejs ; some functions which return a callback

// promises are better way of coding -- code much simpler and easier to maintain

// Object destructuring and array destructuring
var arr=[10,20,30,"fruits"];
var second=arr[1];
var fourth=arr[3];
var arr1=arr;[10,20,30,"fruits"]
var [first]=arr;//10
var [first,,third]=arr;//first=10, third=30
var [s1,s2,,s3]=arr;//s1=10;s2=20;s3="fruits"
var [,,,,,,,s4]=arr;//
console.log("S4 = "+ s4);

var emp={empId:101,empName:"sara",salary:5678};
var sal=emp.salary;
var {salary}=emp;// destructuring the object and getting emp.salary and storing it in salary varaiable
// field name and variable name should be the same
var {sal1}=emp;// sal1=ud 

// Object copy and reference

var emp={empId:101,empName:"sara"};
var emp1=emp;// reference
emp1.empName="Gita";
console.log("Emp1",emp1);//{empId:101,empName:"Gita"};
console.log("Emp",emp);//{empId:101,empName:"Gita"};

// Copy of an object -- spread operator
var emp={empId:101,empName:"sara"};
var empCopy={ ...emp};
empCopy.empName="harry";
console.log("EmpCopy",empCopy);//{empId:101,empName:"harry"};
console.log("Emp",emp);//{empId:101,empName:"sara"};

var empCopyWithAddProps={...emp,salary:4567};
console.log("empCopyWithAddProps",empCopyWithAddProps);//{empId:101,empName:"sara",salary:4567};


var empCopyWithChangedProps={...emp,empId:999};
console.log("empCopyWithChangedProps",empCopyWithChangedProps);//{empId:999,empName:"sara"};

var empCopyWithChangedProps2={empId:999,...emp};
console.log("empCopyWithChangedProps2",empCopyWithChangedProps2);//{empId:101,empName:"sara"};
//var i=10;i=20;console.log(i);//20

/*
Spread operator and rest param
Notation : ...
spread operator : spread an object / array; enclosed within a {} or []
rest param -- as part of function definition; as part of parameter list 
*/