var fs=require("fs");//inbuilt module; core module which is installed whenever node gets installed
// readFile : 3 params
// 1st param : file path to be read
// 2nd param(optional) options
// 3rd param : callback function
// callback function is implicitly executed once the async operation is complete
// async op can be successful -- callback with err as ud and data will be loaded as second param
// async op is failing-- callback with corresponding err as first param will be called
// fs.readFile("text1.txt",(err,data)=>{
//     if(err)
//     {
//         console.log(`Error reading the file : ${err}`);
//     }
//     else
//     {
//         console.log(`Data read from the file :`+data.toString());
//     }

// })
fs.readFile("text1.txt",{encoding:"utf-8",flag:"r"},(err,data)=>{
    if(err)
    {
        console.log(`Error reading the file : ${err}`);
    }
    else
    {
        console.log(`Data read from the file :`+data.toString());
    }

})