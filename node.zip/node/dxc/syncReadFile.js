var fs= require("fs");
/*
readFileSync
    -- reading a file synchronously
    -- Should be always AVOIDED
    -- excuted by the main process of nodejs
    -- Will block the other operations and single thread is forced to execute it
    -- 2 parameters
    -- 1st param : oath to the file
    -- 2nd param :options
*/
try
{
    var data=fs.readFileSync("text1.txt");
    console.log("Data read from the file" + data.toString());
    fs.writeFileSync("text5.txt",data.toString());
    console.log("Write successful");
}
catch(err)
{
    console.log(`Error in reading the file : ${err}`);
}

