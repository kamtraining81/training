var fs=require("fs");
/*
writeFile -- 4 params :
1st param : path of the file into which write has to be done,
2nd param : data to be written
3rd param : options
4th param : callback function

*/
//Replace the old content if the file exists or create the file if the file doesnot exists
fs.writeFile("text2.txt","Welcome to nodejs",(err)=>{
    if(err)
    {
        console.log(`Error during the write operation : ${err}`);
    }
    else
    {
        console.log("Write into the file is successful")
    }
})

//Append the contents if the file exists or create the file if the file doesnot exists
fs.writeFile("text2.txt","Welcome to nodejs",{flag:"a"},(err)=>{
    if(err)
    {
        console.log(`Error during the write operation : ${err}`);
    }
    else
    {
        console.log("Write into the file is successful")
    }
})

