var fs=require("fs");

var rstream=fs.createReadStream("zipcodeData.json");
var wStream=fs.createWriteStream("zipcodeDataCopy1.json");

rstream.pipe(wStream);

rstream.on("error",(err)=>{
    console.log("Error during the read operation" +err);
})

wStream.on("error",(err)=>{
    console.log("Error during the write operation" +err);
})

