// Read from 3 files and put all content together in the fourth file
const fs = require("fs");

fs.readFile("name.txt", (err1, data1) => {
    if (err1) {
        console.log(`err1${err1}`);
    } else {
        fs.readFile("name2.txt", (err2, data2) => {
            if (err2) {
                console.log(`err2${err2}`);
            } else {
                fs.readFile("name3.txt", (err3, data3) => {
                    if (err3) {
                        console.log(`err3${err3}`);
                    } else {
                        let result = data1.toString() + data2.toString() + data3.toString();
                        fs.writeFile("name4.txt", result, (err) => {
                            if (err) {
                                console.log("error writting the file" + err);
                            } else {
                                console.log("write success");
                            }
                        });
                    }
                });
            }
        });
    }
});
