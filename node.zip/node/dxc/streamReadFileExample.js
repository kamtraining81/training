/*
Stream -- huge amounts of data
Break up data into smaller chunks 
Notification mechanism -- events 

Events -- triggering(click the button); handling the event(event handler function gets excuted implicitly)
Read a big file
read the data in chunks
Notifications : 
-- Each time a chunk is read
-- When last chunk has been read and there is no more data to read

Types of streams
1. Read stream
2. Write Stream
3. Duplex stream(Read and write)


Read stream : 
    data event is triggered when a chunk of data has been read
    end event is triggered when all the chunks have been read

    default chunk size  -- 64kb;
    chunk size -- configurable;

*/
const fs=require("fs");
var readStream= fs.createReadStream("zipcodeData.json",{highWaterMark:10000});
var totalData="";
var countOfChunks=0
readStream.on("data",(chunk)=>{
   // console.log("Chunk of data read" + chunk.toString());
    countOfChunks+=1;
    totalData+=chunk.toString()
})
readStream.on("end",()=>{
    console.log("Entire file read");
    console.log("Number of chunks read" + countOfChunks);

})
readStream.on("error",(err)=>{
    console.log(`Error during the read : ${err}`);
})
