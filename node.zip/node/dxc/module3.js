var sqFunc=require("./module1");
var cubeFunc=require("./module2");

var res=sqFunc(5);
console.log(`Square of 5 is ${res}`);
var res=cubeFunc(5);
console.log(`Cube of 5 is ${res}`);