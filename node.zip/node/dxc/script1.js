console.log("Seperate  js file");

// declare a var - var ; let; const
/*
var -- function scope; within the same scope, redeclaration is allowed
let -- block scope; redclaration not allowed within the scope
const -- for a constant declartion
*/

function myFunc()
{
    var i=10;
    for(let j=0;j<i;j++)
    {
        var sum=0;
        console.log(j);
        sum+=j;// 0; 1; 2
    }
    console.log("Sum "+sum);
    console.log("I = "+i);
    //console.log("J"+j);
    
}
myFunc();
/*
Output : 
16 -->0123456789
console.log("Sum "+sum);-->9
    console.log("I = "+i);--> 10 
 console.log("J"+j);--> error j is not defined




*/

function myFunc1()
{
    var i=10;
    for(let j=0;j<i;j++)
    {
        let sum=0;
        console.log(j);
        sum+=j;// 0; 1; 2
    }
    console.log("Sum "+sum);// will not come here
    console.log("I = "+i);
    console.log("J"+j);
    
}
//myFunc1();

// Data types in js -- string, number, date, array, boolean , object, function
// js -- weakly typed language
var str1="hello";
var str1='t';
str1=10;// number
str1=true;
str1=[1,2,3,4,5];
str1=[1,true,"flower"];// elements can belong to different data types

str1={empId:101,empName:"sara"};
str1.empName="Tara";
console.log("Emp details ",str1);//{empId:101,empName:"Tara"}
const PI=3.14;
//PI=3.142;// error

const obj={empId:999,empName:"Sita"};
obj.empName="Geeta";
console.log("Emp Details",obj);//{empId:999,empName:"Geeta"}

//obj={empId:777,empName:"Danny"};//throw an error 
//console.log("Emp Details",obj);

// hoisting of declarations -- declarations will be pushed to top of scope
var num1=100;
console.log("Num4"+ num4);// undefined
console.log("Num1"+ num1);// 100
console.log("Num2"+num2);// undefined; 
//console.log("Num3"+ num3);//error : num3 is not defined
var num2,num4=20;// declaration will be hoisted to top of scope 
console.log("Num4"+ num4);// 20

function myFunc2(p1,p2)
{
    console.log(p1+p2);
}

var result=myFunc2(10,20);//30
var result=myFunc2();//NaN (ud+ud = NaN)
var result=myFunc2(10);//NaN (ud +10 = NaN)
var result=myFunc2(10,20,30);//30
var result=myFunc2(10,20,30,40,50);//30

var result=myFunc2(10,20);//30
var result=myFunc2(10,"20");//1020
var result=myFunc2("10",20);//1020
var result=myFunc2(10,true);//11
var result=myFunc2("10",true);//"10true" 

// function -- accept any number of parameters ; return the sum of all the parameters
function myFunc3()
{
    var sum=0;
    for(let i=0;i<myFunc3.arguments.length;i++)
    {
        sum+=myFunc3.arguments[i];
    }
    console.log(sum);
}
myFunc3();// 0 params; sum=0
myFunc3(10);//1 params; sum=10
myFunc3(10,20);// 2 params; sum=30
myFunc3(10,20,30);// sum=60
myFunc3(10,20,30,40,50);// sum=150

var i=10;
i=20;
console.log(i);// 20

function myFunc4(p1,p2)
{
    console.log(p1+p2);
}
function myFunc4(p1,p2)
{
    console.log(p1-p2);
}
function myFunc4(p1,p2)
{
    return p1*p1;
}
myFunc4(25,15);//(25*25=625);
// javascript -- not an OOPS language ; no overloading , no overriding

// New ES6 feature; rest param :
function myFunc5(...p1)// p1 -- rest parameter
{
// rest parameter works like an array
    var sum=0;
    for(let i=0;i<p1.length;i++)
    {
        sum+=p1[i];
    }
    console.log("Sum "+sum);
}

myFunc5();//0
myFunc5(10);//10
myFunc5(10,20);//30
myFunc5(10,20,30);// 60
myFunc5(10,20,30,40,50);// 5 params will be converted into a array and stored as part of p1;//150

function myFunc6(s1,...p1)// p1 -- rest parameter
{
// rest parameter works like an array
    var sum=s1;
    for(let i=0;i<p1.length;i++)
    {
        sum+=p1[i];
    }
    console.log("Sum "+sum);
}
console.log("myFunc6")
myFunc6();//ud
myFunc6(10);//10
myFunc6(10,20);//30
myFunc6(10,20,30);// 60
myFunc6(10,20,30,40,50);// p1 length =4;//150

/*function myFunc7(...p1,s1);// p1 -- rest parameter
{
// rest parameter works like an array
    var sum=s1;
    for(let i=0;i<p1.length;i++)
    {
        sum+=p1[i];
    }
    console.log("Sum "+sum);
}
console.log("myFunc7")

function myFunc7(...p1,...s1);// p1 -- rest parameter
{
// rest parameter works like an array
    var sum=s1;
    for(let i=0;i<p1.length;i++)
    {
        sum+=p1[i];
    }
    console.log("Sum "+sum);
}
console.log("myFunc7")
*/
// Rest param
// -- work like an array and store all the arguements in the function call as an array
// -- Must be the last param
// -- Can have only one rest param in one function 

// Anonymous function
var myFunc8 =function(p1,p2)
{
    return p1*p2
};
myFunc8();// function literal

//use cases of anonymous function
//1. as part of function declaration
var emp1={
    empId:111,
    empName:"Sara",
    display:function()
    {
        //anonymous function
        console.log("EmpId"+this.empId);
        console.log("Emp Name"+this.empName);
    }
}
emp1.display();
console.log("EmpId "+ emp1.empId);//111
emp1.empName="Gita";
console.log("Emp Name"+emp1.empName);//Gita
//emp1.Gita="sita";// emp1.propertyName; error
//emp1.printDetails();//error


//2. Whenever we pass a function as a parameter to another function
function add2Num(p1,p2)
{
    return p1+p2;
}
function sub2Num(p1,p2)
{
    return p1-p2;
}
function myFunc9(f1,s1,s2)
{
    // f1 data type= function
   // mul2Num(s1,2);// error mul2Num is undefined
    var result=f1(s1,s2);
    console.log(result);
}
myFunc9(add2Num,10,20);//30
myFunc9(sub2Num,10,5);//5
myFunc9(function (p1,p2){return p1*p2},10,20);//200

function myFunc10(i1,i2)
{
    return i1+i2;// correct
    //return a+ b;;// error; a and b are undefined
}
function myFunc11()
{
var a=10,b=20;// avalable only with myFunc11
var r1=myFunc10(a,b);//30
}
myFunc11();


// Function arrow
/*
-- Special type of anonymous function
-- =>
-- lambda function ; fat arrow function
-- Shorter lines of code
-- Difference b/w anonymous function and fat arrow function -- scope of "this" operator

var f1=(p1,p2)=>{
    return p1+p2
}
f1(10,20);//30
var f2=p1=>{return p1*p1}
var f3=()=>{return "hello"};
var f4=p1=>p1*p1;

*/
var empName="Jack";
var emp1={
    empId:111,
    empName:"Sara",
    displayAnonymousFunc:function()
    {
        //anonymous function
        console.log("anonymous function");
        console.log("EmpId"+this.empId);// 111
        console.log("Emp Name"+this.empName);//Sara
    },
    displayFatArrowFunc:() =>{
        // lexical scope -- parent scope
        console.log("Fat arrow function");
        console.log("EmpId"+this.empId);//ud
        console.log("Emp Name"+this.empName);// Jack
    }
}
emp1.displayAnonymousFunc();
emp1.displayFatArrowFunc();

var fruits=["apple","strawberry","pineapple"];
var pos=fruits.findIndex(item =>{ 
    if(item =="strawberry")
        return true;
    else 
        return false;
});
console.log(`Position of strawberry in ${fruits} is ${pos}`);
/*
Dry run:
1st Iteration:
item =apple;return false
2nd iteration
item = strawberry ; return true; stop the traversal; return the index position; 1

*/
var pos=fruits.findIndex(item =>{ 
    if(item =="guava")
        return true;
    else 
        return false;
});
console.log(`Position of guava in ${fruits} is ${pos}`);

var pos=fruits.findIndex(item =>(item =="banana"));
console.log(`Position of banana in ${fruits} is ${pos}`);


/*
1. Function which is going to take in a string and search of a character and return the position
"english", l 
Expected output : 3 


*/






















