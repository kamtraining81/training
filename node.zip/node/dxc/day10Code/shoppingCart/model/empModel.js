var empArray=[];

module.exports=empArray;