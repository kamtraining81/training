var fs=require("fs");
const {createGzip}=require("zlib");

var rstream=fs.createReadStream("zipcodeData.json");
//var wStream=fs.createWriteStream("zipcodeData.json.gz");
var gZip=createGzip();
rstream.pipe(gZip).pipe(wStream);

// Reading from a file and writing to a zip file
// Cannot directly to a write file;

