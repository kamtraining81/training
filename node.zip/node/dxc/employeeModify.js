// add a new employee
// change the employee name for a particular employee
// delete a particular emp for a given empId
// given a empId, get the entire details

function updateEmpName(empName,empNewName) {
    var pos = empArr.findIndex(emp => emp.empName == empName);
    if (pos >= 0) {
        empArr[pos].empName = empNewName;
        return true;
    }
    return false;
}




