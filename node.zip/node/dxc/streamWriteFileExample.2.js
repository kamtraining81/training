var fs=require("fs");

var rstream=fs.createReadStream("zipcodeData.json");
var wStream=fs.createWriteStream("zipcodeDataCopy.json");

// default chunk size : 64kb;
var ctr=0;
rstream.on("data",(chunk)=>{
    ctr++;
    wStream.write(chunk);
})

rstream.on("end",()=>{
    console.log("Number of chunks read and written" +ctr);
    wStream.end();
    // If we Dont call the end method
    //-- Have more contents to be written, waiting for the write
    // -- wStream is open -- misuse of wStream ; cleaning up process 

})

rstream.on("error",(err)=>{
    console.log("Error during the read operation" +err);
})

wStream.on("error",(err)=>{
    console.log("Error during the write operation" +err);
})
fs.mkdir()

/*
Employee obj=newEmployee();

deallocate the memory -- mandatory(you or gc)
*/

/*
Assignments :
1. Copy the contents of a file into another file: fs.copyFile
2. Create a new directory : log07062023; Create a new file with the name dailyLog.log and add the content : "07/06/2023"

*/

