var arr=[10,20,30,40,50];

// Create a function which returns the squares of all the elements without using the map method
//[100,400,900,1600,2500]

// Create a function which takes in a string which holds a phoneNumber and returns the masked version
// var res=createMaskOnPhoneNumber(1234567890); //123****890

// Create a function which takes in array of objects and returns the obj which has the highest salary without using filter/find method
var empArr=[
    {empId:101,empName:"Asha",salary:1001,deptId:"D1"},
{empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
{empId:103,empName:"Karan",salary:2000,deptId:"D2"},
{empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
{empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
{empId:106,empName:"Pran",salary:4000,deptId:"D3"},
{empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]
var obj=getHighestSalaryEmp(empArr);//{empId:106,empName:"Pran",salary:4000,deptId:"D3"}


