console.log("Module2");
var obj=require("./module1");// import some custom module/package -- relative path
var n1=10,n2=20;
var res=obj.addTwoNumsFunction(n1,n2)
console.log(` Sum of ${n1} and ${n2} is ${res}`);
//console.log(str);// thrown an error (str is undeclared)
var res=obj.subTwoNums(n1,n2)
console.log(` Difference of ${n1} and ${n2} is ${res}`);
console.log("Company Name" + obj.str);
var obj=require("./module1");// Rerequiring the same module ; Will it execute module1 again ? No

