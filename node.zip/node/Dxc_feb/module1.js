console.log("Welcome DXC");
var str="DXC";
console.log(str.toLowerCase());

function addTwoNums(p1,p2)
{
    return p1+p2;
}
function subTwoNums(p1,p2)
{
    return p1-p2;
}

var res=addTwoNums(10,20);
console.log("Result = "+res);

var n1=5/0;
console.log(n1);

var s1=parseInt({empId:101});
console.log(s1);

var obj=null;
//console.log(obj.salary);exception 

// module.exports=addTwoNums;
// module.exports=subTwoNums;
module.exports={
    addTwoNumsFunction:addTwoNums,
    subTwoNums:subTwoNums,
    str:"SpringPeople"
}

