console.log("Module5");
var data=require("./module4");

var {findAllPosArrOfObj}=require("./module3");

var posArr=findAllPosArrOfObj(data.empArr,"projectId","P101");

/*
Module5
Module4
Module3
*/