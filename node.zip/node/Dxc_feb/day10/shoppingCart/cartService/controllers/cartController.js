const { getAllProducts } = require("../../controllers/productsController");

const axios = require("axios");
var cartArr = [];

function addItemsToCart(cartObj) {
    cartArr.push(cartObj);// validation if the cart item already exists
    return true;
}

async function getAllCartItems() {
    try {
        var productsArr = await getAllProducts();
        console.log("Products Arr", productsArr);
        var itemsAvailable = [], itemsUnAvailable = [];
        cartArr.forEach(item => {
            var pos = productsArr.findIndex(product => product.productId == item.productId);
            if (pos >= 0) {
                if (item.quantity <= productsArr[pos].quantity) {
                    itemsAvailable.push(item);
                }
                else {
                    itemsUnAvailable.push(item);
                }
            }
        })
        console.log("itemsAvailable", itemsAvailable);
        console.log("itemsUnAvailable", itemsUnAvailable);
        return { itemsAvailable, itemsUnAvailable };
    }
    catch (err) {
        return { err: err };
    }
}


getAllProducts()
{
    // talk to another service
    var serverUrl = "http://localhost:3000/products";
    axios.get(serverUrl)
        .then((res) => {
            console.log("Data from get req to/products", res.data);
            return res.data;
        })
        .catch((err) => {
            console.log("Error in get request to /products");
            return err;

        })
}
function updateItems(finalisedItems)
{
    //update the quantity in the products array to the new quantity values
    finalisedItems.forEach(item => {
        console.log("Item in cart",item)
        var serverUrl = "http://localhost:3000/products/" + item.productId;
        axios.get(serverUrl)
            .then((res) => {
                var newQuantity = res.data.quantity - item.quantity;
                var newObj = { ...res.data, quantity: newQuantity };
                console.log("Updated product item",newObj);
                axios.put(serverUrl, newObj)
                .then((res)=>{
                    console.log("Response of the put",res);
                    //return res;
                })
                .catch(err=>{
                    console.log("Error in put request to /products");
                    //return err;
                })
            })
            .catch((err) => {
                console.log("Error in get request to /products");
                //return err;

            })
    })
}

module.exports = { addItemsToCart, getAllCartItems, updateItems }

