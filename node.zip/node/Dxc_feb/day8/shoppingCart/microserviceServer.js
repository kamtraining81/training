require("dotenv").config();
const express=require("express");//module to be installed
const path=require("path");
const bodyParser=require("body-parser");//module to be installed
const morgan=require("morgan");//module to be installed
const fs=require("fs");
const axios=require("axios");


const port=3001;
var app=express();
app.use(morgan("combined"));

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

app.use(express.static(path.join(__dirname,"public")));

app.get("/products",(request,response)=>{
    axios.get("http://localhost:3000/products")
    .then((data)=>{
        console.log(data.data);
        response.send(data.data);
        
    })
    .catch((err)=>{
        response.send(err)
    })
})
console.log("Express example");
app.listen(port,()=>{
    console.log(`Server started at port : ${port}`);
})