var usersArr=[
    {userName:"sara",password:"sara"}
];

function addUser(userName,password)
{
    var user={userName,password};
    var pos=usersArr.findIndex(person=>person.userName == user.userName);
    if(pos >=0)
        {
            return false;
        }
    else
    {
        usersArr.push(user);
        return true;
    }
}
function checkUser(userName,password)
{
    var pos=usersArr.findIndex(person=> (person.userName=userName && person.password==password))
    if(pos >=0)
        {
            return true;
        }
    else
    {
        return false;
    }
}
module.exports={addUser,checkUser};