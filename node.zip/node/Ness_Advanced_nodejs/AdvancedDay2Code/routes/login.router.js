var express=require("express");
var path=require("path")
var loginRouter=express.Router();
var {checkUser}=require("../controller/user.controller")
var {generateToken,generateTokenWithPromise} =require("../utils");

loginRouter.get("/",(request,response)=>{
    //get request to /login 
    // send register.html
    var filePath=path.join(__dirname,"..","public","login.html")
    response.sendFile(filePath)
})

loginRouter.post("/",(request,response)=>{
    var {userName,password}=request.body;
    if(userName && password)
        {
            // authenticate the user
            var userResult=checkUser(userName,password);
            if(!userResult)
                {
                    response.status(401).send("Username and password do not match");
                }
            // generate the token
                //generateToken(userName,password,response);
                generateTokenWithPromise(userName.password)
                .then((data)=>{
                    response.status(data.statusCode).send({token:data.msg.token});
                })
                .catch((errData)=>{
                    response.status(errData.statusCode).send(errData.msg);
                })
            // store the token in db after encryption
            // send the token as response
            
        }
    else
    {
        response.status(401).send("Username and password not found")
    }
})


module.exports=loginRouter;

/*

*/