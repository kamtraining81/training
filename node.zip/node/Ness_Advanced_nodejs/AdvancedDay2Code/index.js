var express=require("express");
var path=require("path");// core modules; shipped along with nodejs

var registerRouter=require("./routes/register.router")
var loginRouter=require("./routes/login.router");

var {validateToken} =require("./utils")

const PORT=3000;
var app=express();


// work with middlewares
//app.use(express.static("public"));
app.use(express.json())
app.use(express.urlencoded({extended:false}));

// add custom middleware
//app.use(validateToken);// wrong place of adding middleware
// add the routers
app.use("/register",registerRouter);
app.use("/login",loginRouter);

app.get("/",(request,response)=>{
    // response -- index.html;
    var filePath=path.join(__dirname,"public","index.html");
    response.sendFile(filePath);
})




app.listen(PORT,(err)=>{
    if(!err)
        {
            console.log(`Server is listening at http://localhost:${PORT}`);
        }
})