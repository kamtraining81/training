alert("Welcome to js");
/*
int i;
i=10;
j=10;
int j;

*/
console.log(` n1 : ${n1}`);//ud
n1=10;
console.log(` n1 : ${n1}`);//10
var n1=1000;

for(let i=0;i<10;i++)
{
    var sum=0;
    const PI=3.14;
  //  PI=3.142
    sum+=i;
}
//console.log(PI);//9

var arr1=[10,20,30];
var arr2=[10,"hello",67.77]

var emp={empId:101,empName:"sara"};
emp.empId=102;
emp["empName"]="tara";
console.log("Emp details"+emp);
console.log("Emp details",emp);

const obj1={empId:999};
obj1.empId=1000;
console.log("Obj details",obj1);

//obj1={empId:123};
//console.log("Obj details",obj1);

var emp2=emp;
emp2.empId=1;
console.log("Emp details",emp);
console.log("Emp2 details",emp2);

var empCopy={...emp};
var empWithSal={...emp,salary:678};

var empWithDiffId={...emp,empId:666};
console.log("empWithDiffId",empWithDiffId);

var empWithDiffId={empId:666,...emp};
console.log("empWithDiffId",empWithDiffId);//{empId:1,empName:"tara"}

var emp3={empId:888,empName:"sara",project:{projectId:5678}};

var emp3Copy={...emp3};
emp3Copy.project.projectId=999;

console.log("emp3",emp3);
console.log("emp3Copy",emp3Copy);

var emp4Copy={...emp3};
emp4Copy.project={projectloc:"blr"};
console.log("emp3",emp3);
console.log("emp4Copy",emp4Copy);

var arr1=[10,20,30];
var arrCopy=[...arr1];

var arrCopy1=[...arr1,10];
var arrCopy2=[...arr1,...arrCopy1];

function myFunc1(p1,p2)
{
    return p1+p2;
}

myFunc1(10,20);
myFunc1();// NaN
myFunc1(20);//NaN
myFunc1(10,20,30);//30;

myFunc1(10,20);30
myFunc1("10","20");//1020 
myFunc1("10",20);//1020
myFunc1(10,"20",30);//;1020

myFunc1(10,20);30
myFunc1(10,true);//11 
var res=myFunc1(10,[20,30]);//
console.log("res of number and array",res);

var res=myFunc1([20,30],10);//
console.log("res of array and number",res);

function myFunc2()
{
    var sum=0;
    for(let i=0;i<myFunc2.arguments.length;i++)
    {
        sum+=myFunc2.arguments[i];
    }
    console.log(`Sum: ${sum}`);
}

myFunc2(10,20);//30
myFunc2();//0
myFunc2(20);20
myFunc2(10,20,30);//60
myFunc2(10,20,5,3,4,5,6);//

myFunc2("10",20,30);//0102030
myFunc2("10","20",30);//0102030
myFunc2("10",20,"30");//0102030
myFunc2(10,20,"30");//3030

function myFunc3(...p1)
{
    var sum=0;
    for(let i=0;i<p1.length;i++)
    {
        sum+=p1[i];
    }
    console.log(`Sum: ${sum}`);
}
myFunc3(10,20);//30
myFunc3();//0
myFunc3(20);20
myFunc3(10,20,30);//60
myFunc3(10,20,5,3,4,5,6);//


/*function myFunc4(...p1,p2)
{
    var sum=p2;
    for(let i=0;i<p1.length;i++)
    {
        sum+=p1[i];
    }
    console.log(`Sum: ${sum}`);
}
myFunc4(10,20,5,3,4,5,6);//
*/

var p1,p2=10;
console.log(p1);//ud

var [first,second]=[10,20,30];

var [first,,third]=[10,20,30];


var {empId}=emp;
console.log(empId);//1


var today=new Date();

//anonymous function
var f1=function (p1,p2)
{
    return p1+p2;
}

var result=f1(10,20);

var empDetails={
    empId:101,
    empName:"sara",
    printDetails:function (){
        console.log(`EmpId : ${this.empId}`);
        console.log(`EmpName : ${this.empName}`);
    }
}

empDetails.empId=123;
//empDetails.sara="tara";
empDetails.printDetails();
//empDetails.display();

function myFunc4(p1)
{
    var res=p1(10);
    console.log(`Res : ${res}`);
    //var res=myFunc5(10);
    //console.log(`Res : ${res}`);
}

myFunc4(function (s1){return s1*s1 })


var f2=(p1,p2)=>{
    return p1+p2;
}

var f3=p1=> {return p1*p1};
f3(10);//100
var f4=()=> {return "hello"};

var f5=p1=> p1*p1;
var res=f5(100);
console.log(`Res : ${res}`);
var empName="suresh";
var empDetails={
    empId:101,
    empName:"sara",
    printDetails:function (){
        console.log(`EmpId : ${this.empId}`);
        console.log(`EmpName : ${this.empName}`);
    },
    display:(salary)=>{
        console.log("Inside FAF");
        console.log(`EmpId : ${this.empId}`);//1
        console.log(`EmpName : ${this.empName}`);//suresh
        console.log(`EmpId : ${empDetails.empId}`);//101
        console.log(`EmpName : ${empDetails.empName}`);//sara
    },
    myPrint:(thi)=>{
        console.log(`EmpId : ${thi.empId}`);//1
        console.log(`EmpName : ${thi.empName}`);//suresh
        
    },
    myPrint2:()=>{
        console.log(empName);//suresh
    },
    myPrint3:()=>{
        console.log("empName in myPrint3"+this.empName);//suresh
    }
}

empDetails.printDetails();
empDetails.display();
empDetails.myPrint(empDetails);
empDetails.myPrint2();
empDetails.myPrint3=empDetails.myPrint3.bind(empDetails);
empDetails.myPrint3();

