export function cartReducer(state={cartArr:[{productId:'p101',productName:"Apple",quantitySelected:2}]},action)
{
    var newState={...state};
    switch(action.type)
    {
        case "ADD_CART_ITEM":{
            var pos=newState.cartArr.findIndex(item => item.productId == action.payload.productId)
            if(pos >=0)
            {
                newState.cartArr[pos].quantitySelected+=action.payload.quantitySelected;
            }
            else
            {
                newState.cartArr.push(action.payload);
            }
            break;
        }
        case "REMOVE_CART_ITEM":{
            console.log("Inside remove cart reducer")
            var pos=newState.cartArr.findIndex(item => item.productId == action.payload.productId)
            console.log("action",action)
            if(pos >=0)
            {
                newState.cartArr.splice(pos,1);
            }
            console.log("New state in remove ",newState);
            break;
        }
    }
    return newState;
}