export function userReducer(state={userArr:[]},action)
{
    console.log("Inside userReducer");
    var newState={...state};
    switch(action.type)
    {
        case "ADD_USER":{
            var pos=newState.userArr.findIndex(item => item.productId == action.payload.productId)
            if(pos <0)
            {
                newState.userArr.push(action.payload);
            }
            break;
        }
        case "REMOVE_USER":{
            var pos=newState.userArr.findIndex(item => item.productId == action.payload.productId)
            if(pos >=0)
            {
                newState.userArr.splice(pos,1);
            }
            
            break;
        }
    }
    return newState;
}