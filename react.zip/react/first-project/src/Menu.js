import React,{useState,useContext} from 'react'
import { Link } from 'react-router-dom'
import "./Menu.css";
import { AppLoginContext } from './App';

export default function Menu() {
    var appLoginObj=useContext(AppLoginContext)
    
    return (
        <div>
            <ul>
                <li>
                    <Link to="products">Products</Link>
                </li>
                <li>
                    <Link to="users">Users</Link>
                </li>
                {appLoginObj.isLoggedIn && <li>
                    <Link to="manageproducts">Manage Products</Link>
                </li>}
                
                <li>
                    <Link to="register">Sign In</Link>
                </li>
                {!appLoginObj.isLoggedIn &&
                <li>
                    <Link to="login">Login</Link>
                </li>
                }
                <li>
                    <Link to="contactus">Contact Us</Link>
                </li>
                <li>
                    <Link to="aboutus">About Us</Link>
                </li>
                <li>
                    <Link to="courses">Courses</Link>
                </li>
                <li>
                    <Link to="cart">Cart</Link>
                </li>
            </ul>
        </div>
    )
}
