import React from 'react'

export default function Child() {
    console.log("child comp rendered");

  return (
    <div>Child
        <h1>Name: harry </h1>
       
    </div>
  )
}
