import React from "react";

class Header extends React.Component {
    render() {
        //return the virtual DOM
        return (
            <div className='container'>
                <div className="grid grid-cols-3 ">

                    <img src="./logo.jpg" alt="Logo of Palo Alto" className='col-span-1' />
                    <h1 className='col-span-2 align-middle text-6xl text-center '> Palo Alto Networks</h1>
                </div>

            </div>
        )
    }
}

export default Header