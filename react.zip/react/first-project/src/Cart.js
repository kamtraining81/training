import React,{useState} from 'react'
import { useSelector,useDispatch } from 'react-redux'

export function Cart(props)
{
    var dispatch=useDispatch();
    var cartArr=useSelector((state)=>{ 
        return [...state.cart.cartArr]
    })
    var deleteCartItemEventHandler=(cartItemToBeDeleted)=>{
        alert("Inside delete item");
        dispatch({
            type:"REMOVE_CART_ITEM",
            payload:{productId:cartItemToBeDeleted.productId}
        })
    }
    var trArr=cartArr.map((item)=>{
        return(
            <tr key={item.productId}>
                <td style={{border:"5px solid blue"}}>
                    {item.productId}
                </td>
                <td style={{border:"5px solid blue"}}>
                    {item.productName}
                </td>
                <td style={{border:"5px solid blue"}}>
                    {item.quantitySelected}
                </td>
                <td style={{border:"5px solid blue"}}>
                    <input type="button" value="Delete" onClick={()=>{
                        deleteCartItemEventHandler(item);
                    }} className='bg-blue-200'></input>
                </td>
            </tr>
        )
    })
    return (
        <React.Fragment>
            <h1>Cart Component</h1>
            <h2> {JSON.stringify(cartArr)}</h2>
            <table style={{border:"5px solid blue"}}>
                <tbody>
                    {trArr}
                </tbody>
            </table>
        </React.Fragment>
        

    )
}
