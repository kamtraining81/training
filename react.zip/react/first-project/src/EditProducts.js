import React,{useState,useRef,useEffect} from 'react'

export default function EditProducts(props) {
    var priceRef=useRef();
    var nameRef=useRef();
    var selectedProduct={...props.selectedProduct};
    console.log("Props",props);
    console.log("Selected Product",selectedProduct);

    var [newProductName,setNewProductName]=useState(props.selectedProduct.productName);
    var changeProductNameEventHandler=(event)=>{
        console.log(event.target.value);
        setNewProductName(event.target.value);
    }
    var confirmChangesEventHandler=()=>{
        var newPrice =priceRef.current.value;
        alert("New Price "+newPrice);
        var newDetails={...props.selectedProduct,price:newPrice,productName:newProductName};
        props.onConfirmation(newDetails);
    }
    useEffect(()=>{
        nameRef.current.value=props.selectedProduct.productName;
        priceRef.current.value=props.selectedProduct.price;
    },[props.selectedProduct.productId])
    return (
        <React.Fragment>
            <div>EditProducts
                <p> {JSON.stringify(props.selectedProduct)}</p>
            </div>
            <div className='container bg-violet-300'>
                <form>
                    <div>
                        <label>Product Id</label>
                        <label className='m-3'>{selectedProduct.productId}</label>
                    </div>
                    <div>
                        <label>Product Name</label>
                        <input type="text" className='m-3' defaultValue={selectedProduct.productName} onChange={changeProductNameEventHandler} ref={nameRef}/>
                    </div>
                    <div>
                        <label>Price</label>
                        <input type="text" className='m-3' defaultValue={selectedProduct.price} ref={priceRef}/>
                    </div>
                    <div>
                    <input type="button" value="Confirm Changes" onClick={confirmChangesEventHandler}  className='rounded-full p-3 bg-blue-300 m-3'/>               
                    <input type="button" value="Cancel"  className='rounded-full p-3 bg-blue-300 m-3'/>               
                    </div>
                </form>
                <p> Product Name : {newProductName}</p>
            </div>
        </React.Fragment>
    )
}
