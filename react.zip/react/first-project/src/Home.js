import React, { Component } from 'react'
import AddToCart from './AddToCart';

export default class Home extends Component {
    constructor()
    {
        //scope of this operator : class
        super();
        this.testAfEventHandler=this.testAfEventHandler.bind(this);
        //this.showAddToCart=false;
        this.state={ctr:0,showAddToCart:false,selectedProduct:{},
        productsArr : [
            { productId: "P101", productName: "Mac", price: 345678, quantity: 56, imgUrl: "./images/mac.jpg" },
            { productId: "P102", productName: "Hp", price: 54321, quantity: 6, imgUrl: "./images/hp.jpg" },
            { productId: "P103", productName: "Dell", price: 35678, quantity: 12, imgUrl: "./images/dell.jpg" },
            { productId: "P104", productName: "Acer", price: 13678, quantity: 2, imgUrl: "./images/acer.jpg" },
            
        ]
    }
        }
    
    addToCartEventHandler=(selectedProduct)=>{
        alert("Button clicked"+ selectedProduct.productName);
        this.setState({showAddToCart:true,selectedProduct:selectedProduct})
        //this.ctr++;
        //this.state.ctr++;
        // this.setState({ctr:5}, ()=>{
        //     console.log("Ctr"+this.state.ctr);
        // });
        // this.setState({ctr:this.state.ctr+5}, ()=>{
        //     console.log("Ctr"+this.state.ctr);
        // });
        this.setState((prevState)=>{
            return(
                {ctr:prevState.ctr+5}
            )
        }, ()=>{
            console.log("Ctr"+this.state.ctr);
        }); 
    }
    testAfEventHandler=function(){
        alert("AF button clicked"+this.ctr);
    }
    closeAddToCartEventHandler=()=>{
        this.setState({showAddToCart:false});
    }
    onCancelConfirmationEventHandler=()=>{
        alert("Control received from child");
        this.setState({showAddToCart:false});
    }
    onAddToCartConfirmationEventHandler=(cartObj)=>{
        alert("Control received from child"+ JSON.stringify(cartObj));
        this.setState({showAddToCart:false});
        this.setState((prevState)=>{
            var pos=prevState.productsArr.findIndex(product => product.productId== cartObj.productId)
            if(pos >=0)
            {
                prevState.productsArr[pos].quantity-=cartObj.quantitySelected;
            }
            return prevState;
        })
    }
    render() {
        console.log("Render Called!");
    
       
        var products = this.state.productsArr.map(product => {
            return (
                <div className=' card grid grid-cols-1' key={product.productId}>
                    <div className='col-span-1'>
                        <img src={product.imgUrl} />
                    </div>
                    <div>
                        <h1>{product.productName}</h1>
                        <p>Price :{product.price}</p>
                        <p>Quantity :{product.quantity}</p>

                    </div>
                    <div>
                        <input type="button" value="Add To Cart" className='rounded-full p-3 bg-yellow-300' 
                        onClick={()=>{
                            this.addToCartEventHandler(product)
                        }}/>
                        <input type="button" value="TestWithAF" className='rounded-full p-3 bg-yellow-300' onClick={this.testAfEventHandler}/>
                    </div>
                </div>


            )
        })

        return (
            <div className='container mx-auto px-4'>

                <div className='grid grid-cols-1 bg-orange-500 place-items-center'>
                    <div className='grid grid-cols-3 gap-10 m-4'>

                        {products}
                    </div>

                </div>
                <input className='rounded-full p-3 bg-yellow-300'  type="button" value="Close AddToCart" onClick={this.closeAddToCartEventHandler}/>
                Ctr : {this.state.ctr}
                {(this.state.showAddToCart)&& 
                <AddToCart 
                    data="bangalore"
                    selectedProduct={this.state.selectedProduct}
                    onCancelConfirmation={this.onCancelConfirmationEventHandler}
                    onAddToCartConfirmation={this.onAddToCartConfirmationEventHandler}

                    >

                    </AddToCart>}
            </div>

        )
    }
}
/*
constructor
-- called once implicitly
-- called when the instance of class is created
-- initialisations

render
-- lifecycle method
-- called implicitly
-- called after the constructor when the component loads
-- can be called multiple times


state
-- local mutable data for a particular component
-- initialised inside the constructor
-- can be an object

setState(p1,p2)
--asynchronous in nature
-- batched together and executed
-- Updating the state
-- Call the render method implicitly
-- p1 is mandatory, p2 is optional

-- p1: object / function
-- p2 : call back function

update emp set salary=100 wher empId=100

update emp set salary=salary +100 wher empId=101

props
-- immutable data
-- data coming from the parent
*/