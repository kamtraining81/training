import React, { useState, useContext, useEffect } from 'react'
import { useNavigate } from "react-router-dom"
import EditProducts from './EditProducts';
import { LoginContext } from './Main';

export default function Products() {

    var navigate = useNavigate();
    var loginObj = useContext(LoginContext);
    useEffect(() => {
        if (!loginObj.isLoggedIn) {
            alert(JSON.stringify(loginObj));
            navigate("/login");

        }

    }, [])


    var [productsArr, setProductsArr] = useState([
        { productId: "P101", productName: "Mac", price: 345678, quantity: 56, imgUrl: "./images/mac.jpg" },
        { productId: "P102", productName: "Hp", price: 54321, quantity: 6, imgUrl: "./images/hp.jpg" },
        { productId: "P103", productName: "Dell", price: 35678, quantity: 12, imgUrl: "./images/dell.jpg" },
        { productId: "P104", productName: "Acer", price: 13678, quantity: 2, imgUrl: "./images/acer.jpg" },

    ])
    var [showEditProduct, setShowEditProduct] = useState(false);
    var [selectedProduct, setSelectedProduct] = useState({});
    var editEventHandler = (selectedProduct) => {
        setShowEditProduct(true);
        setSelectedProduct(selectedProduct);
    }
    var onConfirmationEventHandler = (newDetails) => {
        console.log("Function in parent called")
        setProductsArr((prevProductsArr) => {
            var pos = prevProductsArr.findIndex(item => item.productId == newDetails.productId);
            if (pos >= 0) {
                prevProductsArr[pos].productName = newDetails.productName;
                prevProductsArr[pos].price = newDetails.price;

            }
            return [...prevProductsArr];
        })
        setShowEditProduct(false);
    }
    var detailsEventHandler = (selectedProduct) => {
        // navigate to ProductDetails component
        navigate("/productDetails/" + selectedProduct.productId, { state: { selectedProduct: selectedProduct } })

    }
    var rowArr = productsArr.map(product => {
        return (
            <div key={product.productId} className='grid grid-flow-col'>
                <p className='col-span-1'>{product.productId}</p>
                <p className='col-span-1'>{product.productName}</p>
                <p className='col-span-1'>{product.price}</p>
                <p className='col-span-1'>
                    <input type="button" value="Edit" onClick={() => { editEventHandler(product) }} className='rounded-full p-3 bg-blue-300 m-3' />
                    <input type="button" value="Delete" className='rounded-full p-3 bg-blue-300 m-3' />
                    <input type="button" value="Details" className='rounded-full p-3 bg-blue-300 m-3' onClick={() => { detailsEventHandler(product) }} />

                </p>
            </div>
        )
    })
    return (
        
            (loginObj.isLoggedIn)
            ?(
                <div>Products Component
                    <h1>Login Obj :{loginObj.isLoggedIn ? "yes" : "no"}</h1>
                    <div className='grid grid-flow-row bg-cyan-200 text-blue-700'>
                        <div className='grid grid-flow-col bg-purple-50'>
                            <p className="col-span-1">Product Id</p>
                            <p className="col-span-1">Name</p>
                            <p className="col-span-1">Price</p>
                            <p className="col-span-1">Actions
                            </p>
                        </div>
                        <div>
                            {rowArr}
                        </div>
                    </div>
                    <div>
                        {showEditProduct &&
                            <EditProducts
                                selectedProduct={selectedProduct}
                                onConfirmation={onConfirmationEventHandler}
                            >

                            </EditProducts>}
                    </div>
                    <div >
                        <input type="button" value="Add new Product" className='rounded-full p-3 bg-blue-300 m-3' />
                    </div>
                </div>
            )
            :null
        
    
  )
}
