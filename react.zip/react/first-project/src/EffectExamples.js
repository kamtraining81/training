import React,{useEffect,useState} from 'react'

export default function EffectExamples() {
    var [ctr, setCtr] = useState(0);
   var [ctr1, setCtr1] = useState(0);
   
    useEffect(()=>{
        console.log("Use effect with only 1st param called");
    })

    useEffect(()=>{
        console.log("Use effect with 1st param and empty array as second param");
    },[])
    useEffect(()=>{
        console.log("Use effect 2with only 1st param called");
    })
    alert("Ctr :"+ctr);
    useEffect(()=>{
        console.log("Use effect with 1st param and ctr as second param");
    },[ctr])
    

    var cN="palo Alto"
    console.log("Inside functional component");
    //setCtr(100);will result in an infinite loop
    var changeQuantityEventHandler=(op)=>{
        if(op =="dec")
        {
            //setCtr(ctr-1);
            setCtr((prevCtr)=>{
                return prevCtr-1;
            })
        }
        else
        {
            cN="jj";
            console.log("Value of cn"+ cN);
            setCtr((prevCtr)=>{
                return prevCtr+1;
            })
        }
    }

    var changeQuantityEventHandler1=(op)=>{
        if(op =="dec")
        {
            //setCtr(ctr-1);
            setCtr1((prevCtr)=>{
                return prevCtr-1;
            })
        }
        else
        {
            cN="jj";
            console.log("Value of cn"+ cN);
            setCtr1((prevCtr)=>{
                return prevCtr+1;
            })
        }
    }
    return (
        <div>EffectExamples
            <div>
                <input type="button" value="-" className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler("dec") }} />
                {ctr}
               
                <input type="button" value="+"  className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler("inc") }} />
            </div>

            <div>
                <input type="button" value="-" className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler1("dec") }} />
                {ctr1}
               
                <input type="button" value="+"  className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler1("inc") }} />
            </div>

        </div>
    )
}
