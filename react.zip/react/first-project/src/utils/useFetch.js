import axios from "axios";
import { useState, useEffect } from "react";
export default function useFetch(url) {
    var [data, setData] = useState({})
    var [err, setErr] = useState({})

    useEffect(() => {
        var s1 = async () => {
            await axios.get(url)
                .then((response) => {
                    setData(response.data.data);
                })
                .catch((err) => {
                    setErr(err);
                })
        };
        s1();
    }, [])

    return ({ data: data, err: err });
}