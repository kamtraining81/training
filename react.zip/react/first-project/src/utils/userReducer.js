
export function userReducer(state,action)
{
    console.log("Reducer called with action",action);
    var newState={...state};
    newState.error.message="";
    switch(action.type)
    {
        case "CREATE_USERS_ARR":{
            newState.usersArr=action.payload.data;
            break;
        }
        case "ADD_USER":{
            var pos=newState.usersArr.findIndex(user => user.id == action.payload.newUser.id);
            if(pos <0)
            {
                newState.usersArr.push(action.payload.newUser);
            }
            else
            {
                newState.error.message="User Id already exists";
            }
            break;
        }
        case "DELETE_USER":
            {
                // data : newState.usersArr
                // id to be deleted : action.payload.id
                var pos=newState.usersArr.findIndex(user => user.id == action.payload.id);
                if(pos >=0)
                {
                	newState.usersArr.splice(pos,1);
                }
                break;
            }
        case "EDIT_USER":
            {
                //data : newState.usersArr
                // payload : id, newName
                var pos=newState.usersArr.findIndex(item => item.id == action.payload.id)
                if(pos>=0)
                {
                    newState.usersArr[pos].first_name=action.payload.newName;
                }
                break;
            }
    }
    return newState
}

/*
var empId=101;
var obj={empId:empId};
var obj={empId}
*/

