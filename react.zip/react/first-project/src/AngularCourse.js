import React from 'react'

export default function AngularCourse() {
  return (
    <div className="bg-violet-400"> 
    AngularCourse
    </div>
  )
}
