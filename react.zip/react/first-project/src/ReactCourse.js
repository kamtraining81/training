import React from 'react'

export default function ReactCourse() {
  return (
    <div className="bg-violet-400"> 
        ReactCourse</div>
  )
}
