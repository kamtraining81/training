import React from 'react'
import useFetch from "./utils/useFetch";

export default function CustomHookExample() {
    var serverUrl="https://reqres.in/api/users?page=2";
        
    var {data,err}=useFetch(serverUrl);
   
    var serverUrl="https://reqres.in/api/users?page=1";
    var obj=useFetch(serverUrl);
   // console.log("data",data);
  return (
    <div>CustomHookExample
        <h1>Data : {JSON.stringify(data)}</h1>
        <h1>************************</h1>
        <h1> Data :{JSON.stringify(obj.data)}</h1>
    </div>
  )
}
